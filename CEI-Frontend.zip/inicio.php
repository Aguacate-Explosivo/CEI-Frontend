<?php 
include_once("footer.php");
 ?>